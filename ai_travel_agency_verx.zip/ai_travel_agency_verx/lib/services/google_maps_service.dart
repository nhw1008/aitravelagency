// lib/services/google_maps_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:google_maps_flutter/google_maps_flutter.dart';

class GoogleMapsService {
  static const String _apiKey = 'YOUR_GOOGLE_MAPS_API_KEY';

  // Routes API를 사용한 실제 경로 계산
  static Future<List<LatLng>> getDirections({
    required LatLng origin,
    required LatLng destination,
    String travelMode = 'WALKING', // DRIVING, WALKING, TRANSIT, BICYCLING
  }) async {
    try {
      final response = await http.post(
        Uri.parse('https://routes.googleapis.com/directions/v2:computeRoutes'),
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': _apiKey,
          'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline',
        },
        body: jsonEncode({
          'origin': {
            'location': {
              'latLng': {
                'latitude': origin.latitude,
                'longitude': origin.longitude,
              }
            }
          },
          'destination': {
            'location': {
              'latLng': {
                'latitude': destination.latitude,
                'longitude': destination.longitude,
              }
            }
          },
          'travelMode': travelMode,
          'routingPreference': 'TRAFFIC_AWARE',
          'computeAlternativeRoutes': false,
          'routeModifiers': {
            'avoidTolls': false,
            'avoidHighways': false,
            'avoidFerries': false,
          },
          'languageCode': 'ko',
          'units': 'METRIC',
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['routes'] != null && data['routes'].isNotEmpty) {
          final route = data['routes'][0];
          final encodedPolyline = route['polyline']['encodedPolyline'];

          // 인코딩된 polyline을 LatLng 리스트로 디코딩
          return _decodePolyline(encodedPolyline);
        }
      } else {
        print('Routes API 오류: ${response.statusCode}');
        print('응답: ${response.body}');
      }
    } catch (e) {
      print('Routes API 호출 오류: $e');
    }

    // 실패 시 직선 경로 반환
    return [origin, destination];
  }

  // 여러 지점을 거치는 경로 계산
  static Future<List<LatLng>> getMultiStopRoute({
    required LatLng origin,
    required LatLng destination,
    required List<LatLng> waypoints,
    String travelMode = 'WALKING',
  }) async {
    try {
      List<Map<String, dynamic>> waypointsList = waypoints.map((point) => {
        'location': {
          'latLng': {
            'latitude': point.latitude,
            'longitude': point.longitude,
          }
        }
      }).toList();

      final response = await http.post(
        Uri.parse('https://routes.googleapis.com/directions/v2:computeRoutes'),
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': _apiKey,
          'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline,routes.legs',
        },
        body: jsonEncode({
          'origin': {
            'location': {
              'latLng': {
                'latitude': origin.latitude,
                'longitude': origin.longitude,
              }
            }
          },
          'destination': {
            'location': {
              'latLng': {
                'latitude': destination.latitude,
                'longitude': destination.longitude,
              }
            }
          },
          'intermediates': waypointsList,
          'travelMode': travelMode,
          'routingPreference': 'TRAFFIC_AWARE',
          'optimizeWaypointOrder': true, // 경유지 순서 최적화
          'languageCode': 'ko',
          'units': 'METRIC',
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['routes'] != null && data['routes'].isNotEmpty) {
          final route = data['routes'][0];
          final encodedPolyline = route['polyline']['encodedPolyline'];

          return _decodePolyline(encodedPolyline);
        }
      }
    } catch (e) {
      print('Multi-stop route 오류: $e');
    }

    return [origin, ...waypoints, destination];
  }

  // Google Polyline 디코딩 함수
  static List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> polylineCoordinates = [];
    int index = 0;
    int len = encoded.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int b;
      int shift = 0;
      int result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      polylineCoordinates.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return polylineCoordinates;
  }

  // Places API 검색
  static Future<List<PlaceInfo>> searchNearbyPlaces({
    required LatLng location,
    required String type,
    int radius = 5000,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('https://maps.googleapis.com/maps/api/place/nearbysearch/json'
            '?location=${location.latitude},${location.longitude}'
            '&radius=$radius'
            '&type=$type'
            '&key=$_apiKey'
            '&language=ko'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List<PlaceInfo> places = [];

        for (var result in data['results']) {
          places.add(PlaceInfo(
            placeId: result['place_id'],
            name: result['name'],
            address: result['vicinity'] ?? '',
            location: LatLng(
              result['geometry']['location']['lat'],
              result['geometry']['location']['lng'],
            ),
            rating: (result['rating'] ?? 0.0).toDouble(),
          ));
        }

        return places;
      }
    } catch (e) {
      print('Places API 오류: $e');
    }

    return [];
  }
}

class PlaceInfo {
  final String placeId;
  final String name;
  final String address;
  final LatLng location;
  final double rating;

  PlaceInfo({
    required this.placeId,
    required this.name,
    required this.address,
    required this.location,
    required this.rating,
  });
}
