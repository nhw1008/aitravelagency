import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/travel_plan.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class AIService {
  static Future<List<DayPlan>> generateTravelPlan({
    required String destination,
    required DateTime startDate,
    required DateTime endDate,
    required String budget,
    List<TimeOfDay>? startTimes,
    List<TimeOfDay>? endTimes,
  }) async {
    try {
      final days = endDate.difference(startDate).inDays + 1;
      List<int> dailyAvailableHours = [];
      List<String> dailyTimeInfo = [];

      for (int i = 0; i < days; i++) {
        final startTime = startTimes?[i] ?? TimeOfDay(hour: 9, minute: 0);
        final endTime = endTimes?[i] ?? TimeOfDay(hour: 19, minute: 0);

        int startMinutes = startTime.hour * 60 + startTime.minute;
        int endMinutes = endTime.hour * 60 + endTime.minute;
        if (endMinutes <= startMinutes) endMinutes += 24 * 60;
        int availableMinutes = endMinutes - startMinutes;
        int availableHours = (availableMinutes / 60).round();

        dailyAvailableHours.add(availableHours);
        dailyTimeInfo.add('${i + 1}일차: ${_formatTime24(startTime)}~${_formatTime24(endTime)} (${availableHours}시간)');
      }

      final prompt = '''
$destination 여행 계획을 JSON으로 생성하세요.

**기본 정보:**
목적지: $destination
일수: $days일
일차별 시간: ${dailyTimeInfo.join('\n')}

**절대 금지 사항:**
❌ 같은 식당을 여러 번 방문 절대 금지
❌ 같은 제목의 활동 반복 금지
❌ 비현실적인 이동거리 (5km 이상) 금지
❌ 다른 도시 식당 절대 금지 (오사카 여행 시 도쿄 식당 금지)

**지역별 맞춤 규칙:**
${_getRegionSpecificRules(destination)}

**이동 효율성 규칙:**
✅ 연속 활동 간 이동거리 3km 이하 유지
✅ 이동시간 30분 이하로 제한
✅ 같은 지역 내에서 활동 그룹화
✅ 하루 최대 2-3개 지역만 방문

**시간 활용 규칙:**
✅ 모든 일차의 가용시간을 100% 활용

**다양성 강제 규칙:**
✅ 매일 다른 식당 사용 필수
✅ $days일간 최소 ${days * 2}개 이상의 서로 다른 식당/카페
✅ 현지 특색 음식 포함 필수

**JSON 형식:**
{
  "days": [
    {
      "day": 1,
      "date": "${startDate.add(Duration(days: 0)).toString().split(' ')[0]}",
      "activities": [
        {
          "time": "09:00",
          "title": "${_getExampleRestaurant(destination)}",
          "description": "현지 유명 맛집에서 ${_getLocalCuisine(destination)}을 맛봅니다",
          "type": "dining",
          "location": "${_getExampleLocation(destination)}",
          "duration": "1시간",
          "coordinates": {"lat": ${_getExampleCoords(destination)['lat']}, "lng": ${_getExampleCoords(destination)['lng']}}
        }
      ]
    }
  ]
}

JSON만 반환하고 다른 텍스트는 포함하지 마세요.
''';

      final response = await http.post(
        Uri.parse('http://localhost:3000/api/ai'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'model': 'llama-3.1-sonar-small-128k-online',
          'messages': [
            {
              'role': 'system',
              'content': '당신은 여행 플래너입니다. JSON 형식으로만 응답하세요. 같은 식당을 절대 중복하지 마세요. 해당 도시의 현지 식당만 추천하세요.'
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'max_tokens': 4000,
          'temperature': 0.3,
        }),
      );

      print('=== Perplexity API Response Status ===');
      print(response.statusCode);
      print('=== Perplexity API Response Body ===');
      print(response.body);
      print('======================================');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final aiResponse = data['choices'][0]['message']['content'];

        print('=== AI 원본 응답 ===');
        print(aiResponse);
        print('==================');

        String cleaned = _extractJsonFromResponse(aiResponse);

        print('=== 정리된 응답 ===');
        print(cleaned);
        print('==================');

        try {
          final planData = jsonDecode(cleaned);

          _validateAndFixCoordinates(planData);
          final enhancedPlan = await _enhanceWithLocationBasedPlaces(planData);
          final parsedPlan = await _parseTravelPlan(enhancedPlan);
          return parsedPlan;
        } catch (e) {
          print('JSON 파싱 오류: $e - fallback 사용');
          return _generateFallbackPlan(destination, startDate, endDate, startTimes, endTimes);
        }
      } else {
        print('API 응답 오류: ${response.statusCode}');
        return _generateFallbackPlan(destination, startDate, endDate, startTimes, endTimes);
      }
    } catch (e) {
      print('AI Service Error: $e');
      return _generateFallbackPlan(destination, startDate, endDate, startTimes, endTimes);
    }
  }

  // 지역별 맞춤 규칙 (한국 제외, 4개 도시만)
  static String _getRegionSpecificRules(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return '''
**오사카 특화 규칙:**
✅ 지역별 클러스터링: 도톤보리-난바, 우메다-오사카역, 신세카이-텐노지, 스미요시-난코
✅ 오사카 현지 음식: 타코야키, 오코노미야키, 쿠시카츠, 우동, 타이야키
✅ 대표 식당: 타코야키 와나카, 미즈노 오코노미야키, 다루마 쿠시카츠, 우동 스키
✅ 교통: 오사카 메트로, JR 간사이선 중심 (20분 이내)
✅ 오사카만의 특색: 유니버셜 스튜디오 재팬, 오사카성, 구로몬 시장
        ''';

      case '도쿄':
      case 'tokyo':
        return '''
**도쿄 특화 규칙:**
✅ 지역별 클러스터링: 시부야-하라주쿠, 긴자-도쿄역, 아사쿠사-우에노, 신주쿠-이케부쿠로
✅ 일본 현지 음식: 라멘, 스시, 텐동, 야키니쿠, 오코노미야키
✅ 대표 식당: 이치란 라멘, 스시잔마이, 카니도라쿠, 야키니쿠 킹
✅ 교통: JR선, 지하철 중심 이동 (30분 이내)
✅ 도쿄만의 특색: 도쿄 타워, 스카이트리, 메이지 신궁, 센소지
        ''';

      case '홍콩':
      case 'hong kong':
        return '''
**홍콩 특화 규칙:**
✅ 지역별 클러스터링: 센트럴-애드미럴티, 침사추이-몽콕, 코즈웨이베이-완차이, 센트럴-미드레벨
✅ 홍콩 현지 음식: 딤섬, 차찬텡, 로스트구스, 완탕면, 에그타르트, 밀크티
✅ 대표 식당: 팀호완 딤섬, 마맥스 누들, 카메론 로드 스낵스, 호놀룰루 커피
✅ 교통: MTR, 트램, 스타페리, 미니버스 중심 (25분 이내)
✅ 홍콩만의 특색: 빅토리아 피크, 심포니 오브 라이츠, 템플 스트리트, 스타페리
        ''';

      case '타이페이':
      case 'taipei':
        return '''
**타이페이 특화 규칙:**
✅ 지역별 클러스터링: 시먼딩-중정, 신이-다안, 스린-베이투, 시린-난강, 반차오-신좡
✅ 대만 현지 음식: 샤오롱바오, 루로판, 지파이, 펀위안, 타이완 맥주, 망고빙수
✅ 대표 식당: 딘타이펑, 아종면선, 스린 야시장 맛집, 이민 루로판
✅ 교통: MRT, 버스, 유바이크 중심 이동 (25분 이내)
✅ 타이페이만의 특색: 타이페이 101, 스린 야시장, 지우펀, 양명산
        ''';

      default:
        return '''
**일반 규칙:**
✅ 현지 특색 음식 위주로 구성
✅ 대중교통 이용 30분 이내 이동
✅ 지역별 클러스터링 적용
✅ 현지 문화와 관습 존중
        ''';
    }
  }

  // 지역별 예시 식당 (한국 제외)
  static String _getExampleRestaurant(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return '타코야키 와나카 도톤보리점';
      case '도쿄':
      case 'tokyo':
        return '이치란 라멘 시부야점';
      case '홍콩':
      case 'hong kong':
        return '팀호완 센트럴점';
      case '타이페이':
      case 'taipei':
        return '딘타이펑 신의점';
      default:
        return '현지 유명 맛집';
    }
  }

  // 지역별 현지 음식 (한국 제외)
  static String _getLocalCuisine(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return '바삭한 타코야키';
      case '도쿄':
      case 'tokyo':
        return '진한 돈코츠 라멘';
      case '홍콩':
      case 'hong kong':
        return '정통 딤섬';
      case '타이페이':
      case 'taipei':
        return '수제 샤오롱바오';
      default:
        return '현지 특색 음식';
    }
  }

  // 지역별 예시 좌표 (한국 제외)
  static Map<String, double> _getExampleCoords(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return {'lat': 34.6694, 'lng': 135.5054}; // 도톤보리
      case '도쿄':
      case 'tokyo':
        return {'lat': 35.6762, 'lng': 139.6503}; // 시부야
      case '홍콩':
      case 'hong kong':
        return {'lat': 22.2793, 'lng': 114.1628}; // 센트럴
      case '타이페이':
      case 'taipei':
        return {'lat': 25.0340, 'lng': 121.5645}; // 신의구
      default:
        return {'lat': 35.6762, 'lng': 139.6503};
    }
  }

  // 지역별 예시 위치 (한국 제외)
  static String _getExampleLocation(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return '오사카시 주오구 도톤보리 1-1-1';
      case '도쿄':
      case 'tokyo':
        return '시부야구 우다가와초 21-1';
      case '홍콩':
      case 'hong kong':
        return 'Central, Hong Kong Island';
      case '타이페이':
      case 'taipei':
        return '타이페이시 신의구 신의로 1-1';
      default:
        return '현지 주소';
    }
  }

  static String _extractJsonFromResponse(String response) {
    String cleaned = response
        .replaceAll(RegExp(r'^```[a-zA-Z]*\s*', multiLine: true), '')
        .replaceAll(RegExp(r'```\n?', multiLine: true), '')
        .trim();

        cleaned = cleaned.replaceAll(RegExp(r'//.*$', multiLine: true), '');
    cleaned = cleaned.replaceAll(RegExp(r'/\*.*?\*/', dotAll: true), '');
    cleaned = cleaned.replaceAll('trải nghiệm', '체험');
    cleaned = cleaned.replaceAll(RegExp(r'[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]'), '');

    final lines = cleaned.split('\n');
    int jsonStartLine = -1;
    for (int i = 0; i < lines.length; i++) {
      if (lines[i].trim().startsWith('{')) {
        jsonStartLine = i;
        break;
      }
    }

    if (jsonStartLine != -1) {
      cleaned = lines.sublist(jsonStartLine).join('\n');
    }

    int jsonStart = cleaned.indexOf('{');
    int jsonEnd = cleaned.lastIndexOf('}');

    if (jsonStart != -1 && jsonEnd != -1 && jsonStart < jsonEnd) {
      cleaned = cleaned.substring(jsonStart, jsonEnd + 1);
    }

    cleaned = cleaned.replaceAll(RegExp(r'"lat":\s*35\.xxx'), '"lat": 35.6762');
    cleaned = cleaned.replaceAll(RegExp(r'"lng":\s*139\.xxx'), '"lng": 139.6503');
    cleaned = cleaned.replaceAll(RegExp(r'"lat":\s*\d+\.xxx'), '"lat": 35.6762');
    cleaned = cleaned.replaceAll(RegExp(r'"lng":\s*\d+\.xxx'), '"lng": 139.6503');

    return cleaned;
  }

  static void _validateAndFixCoordinates(Map<String, dynamic> planData) {
    if (planData['days'] != null) {
      Set<String> usedCoords = {};
      Set<String> usedTitles = {};
      Set<String> usedRestaurants = {};

      for (var day in planData['days']) {
        if (day['activities'] != null) {
          List<dynamic> validActivities = [];

          for (int i = 0; i < day['activities'].length; i++) {
            var activity = day['activities'][i];
            final title = activity['title']?.toString() ?? '';
            final type = activity['type']?.toString() ?? '';

            if (usedTitles.contains(title)) {
              print('🔧 중복 제목 제거: $title');
              continue;
            }

            if (type == 'dining' || type == 'cafe') {
              bool isDuplicate = false;
              String restaurantName = _extractRestaurantName(title);

              for (String usedRestaurant in usedRestaurants) {
                if (_isSimilarRestaurant(restaurantName, usedRestaurant)) {
                  print('🔧 유사 식당명 제거: $title (기존: $usedRestaurant)');
                  isDuplicate = true;
                  break;
                }
              }

              if (isDuplicate) continue;
              usedRestaurants.add(restaurantName);
            }

            if (activity['location'] is Map && activity['coordinates'] == null) {
              activity['coordinates'] = activity['location'];
              activity['location'] = activity['location']['address'] ?? '주소 정보 없음';
              print('🔧 location을 coordinates로 변환: ${activity['title']}');
            }

            if (activity['coordinates'] == null) {
              activity['coordinates'] = {
                'lat': 35.6762 + (i * 0.001),
                'lng': 139.6503 + (i * 0.001)
              };
              print('🔧 기본 좌표 설정: ${activity['title']}');
            }

            if (activity['coordinates'] != null) {
              var coords = activity['coordinates'];

              if (coords['lat'] is String || coords['lng'] is String) {
                coords['lat'] = 35.6762;
                coords['lng'] = 139.6503;
                print('🔧 잘못된 좌표 수정: ${activity['title']}');
              }

              String coordKey = '${coords['lat']}_${coords['lng']}';
              if (usedCoords.contains(coordKey)) {
                coords['lat'] = coords['lat'] + (i * 0.001);
                coords['lng'] = coords['lng'] + (i * 0.001);
                print('🔧 중복 좌표 수정: ${activity['title']}');
              }

              usedCoords.add('${coords['lat']}_${coords['lng']}');
            }

            usedTitles.add(title);
            validActivities.add(activity);
          }

          day['activities'] = validActivities;
        }
      }
    }
  }

  static String _extractRestaurantName(String title) {
    final patterns = [
      RegExp(r'^(.+?)\s+[가-힣]+점$'),
      RegExp(r'^(.+?)\s+[가-힣]+지점$'),
      RegExp(r'^(.+?)\s+[가-힣]+역점$'),
      RegExp(r'^(.+?)\s+[가-힣]+본점$'),
    ];

    for (var pattern in patterns) {
      final match = pattern.firstMatch(title);
      if (match != null) {
        return match.group(1)!;
      }
    }

    return title;
  }

  static bool _isSimilarRestaurant(String name1, String name2) {
    if (name1 == name2) return true;
    if (name1.contains(name2) || name2.contains(name1)) return true;

    final keywords1 = name1.split(' ');
    final keywords2 = name2.split(' ');

    for (String keyword1 in keywords1) {
      for (String keyword2 in keywords2) {
        if (keyword1.length > 1 && keyword1 == keyword2) {
          return true;
        }
      }
    }

    return false;
  }

  static Future<Map<String, dynamic>> _enhanceWithLocationBasedPlaces(
      Map<String, dynamic> planData
      ) async {
    try {
      if (planData['days'] != null) {
        for (var day in planData['days']) {
          if (day['activities'] != null) {
            for (int i = 0; i < day['activities'].length; i++) {
              var activity = day['activities'][i];

              _fixDataTypes(activity, day);

              if (_shouldEnhanceWithPlaces(activity)) {
                await _enhanceActivityWithNearbyPlaces(activity, i);
              }

              _removeInvalidCharacters(activity);
            }
          }
        }
      }
      return planData;
    } catch (e) {
      print('Places API 보완 중 오류: $e');
      return planData;
    }
  }

  static bool _shouldEnhanceWithPlaces(Map<String, dynamic> activity) {
    final type = activity['type']?.toString() ?? '';
    final title = activity['title']?.toString() ?? '';

    if (type == 'dining' || type == 'cafe') {
      final genericTitles = ['점심', '저녁', '아침', '식사', '카페', '휴식'];
      return genericTitles.any((generic) => title.contains(generic));
    }
    return false;
  }

  static void _fixDataTypes(Map<String, dynamic> activity, Map<String, dynamic> day) {
    if (activity['duration'] is int) {
      activity['duration'] = '${activity['duration']}시간';
    }
    if (day['total_available_time'] is int) {
      day['total_available_time'] = '${day['total_available_time']}시간';
    }
    if (activity['time'] == null) activity['time'] = '09:00';
    if (activity['description'] == null) activity['description'] = '';
    if (activity['location'] == null) activity['location'] = '';
  }

  static Future<void> _enhanceActivityWithNearbyPlaces(
      Map<String, dynamic> activity,
      int activityIndex
      ) async {
    final title = activity['title']?.toString() ?? '';
    final type = activity['type']?.toString() ?? 'dining';

    Map<String, double>? currentCoords;

    if (activity['coordinates'] != null) {
      try {
        currentCoords = {
          'lat': activity['coordinates']['lat'].toDouble(),
          'lng': activity['coordinates']['lng'].toDouble(),
        };
        print('📍 coordinates 필드에서 좌표 발견: ${currentCoords['lat']}, ${currentCoords['lng']}');
      } catch (e) {
        print('coordinates 파싱 오류: $e');
      }
    }

    if (currentCoords == null && activity['location'] is Map) {
      try {
        currentCoords = {
          'lat': activity['location']['lat'].toDouble(),
          'lng': activity['location']['lng'].toDouble(),
        };
        print('📍 location 필드에서 좌표 발견: ${currentCoords['lat']}, ${currentCoords['lng']}');
      } catch (e) {
        print('location 파싱 오류: $e');
      }
    }

    if (currentCoords == null) {
      print('⚠️ 좌표 정보 없음 - Places API 건너뛰기');
      return;
    }

    print('🔍 Places API 검색: $title ($type)');
    print('   📍 좌표: ${currentCoords['lat']}, ${currentCoords['lng']}');

    String searchType = type == 'cafe' ? 'cafe' : 'restaurant';
    final places = await _searchNearbyPlaces(currentCoords, searchType, activityIndex);

    if (places.isNotEmpty) {
      final randomSeed = DateTime.now().millisecondsSinceEpoch + activityIndex * 1000;
      final selectedIndex = randomSeed % places.length;
      final selectedPlace = places[selectedIndex];

      activity['title'] = selectedPlace['name'];
      activity['location'] = selectedPlace['address'];

      activity['coordinates'] = {
        'lat': selectedPlace['latitude'],
        'lng': selectedPlace['longitude']
      };

      final originalDesc = activity['description']?.toString() ?? '';
      if (originalDesc.isEmpty) {
        activity['description'] = '${selectedPlace['name']}에서 ${type == 'cafe' ? '커피와 휴식' : '현지 음식'}을 즐깁니다.';
      }

      print('✅ Places API 성공: ${selectedPlace['name']} (평점: ${selectedPlace['rating']})');
      print('   📍 새 좌표: ${selectedPlace['latitude']}, ${selectedPlace['longitude']}');
    } else {
      print('⚠️ Places API 결과 없음 - 기존 제목 유지');
    }
  }

  static Future<List<Map<String, dynamic>>> _searchNearbyPlaces(
      Map<String, double> coords,
      String type,
      int activityIndex
      ) async {
    try {
      final lat = coords['lat'];
      final lng = coords['lng'];
      final radius = 800;

      final response = await http.get(
        Uri.parse('http://localhost:3000/api/places/nearbysearch?location=$lat,$lng&radius=$radius&type=$type&language=ko'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null && data['results'].isNotEmpty) {
          List<Map<String, dynamic>> places = [];

          for (var place in data['results'].take(20)) {
            final name = place['name'] ?? '';

            if (name.toLowerCase().contains('hotel') ||
                name.toLowerCase().contains('호텔') ||
                name.contains('Hotel') ||
                name.contains('Tokyu') ||
                name.contains('Inn') ||
                name.contains('Resort') ||
                name.contains('Lodge')) {
              continue;
            }

            if (place['rating'] != null && place['rating'] >= 4.0) {
              places.add({
                'name': name,
                'address': place['vicinity'] ?? '',
                'latitude': place['geometry']['location']['lat'],
                'longitude': place['geometry']['location']['lng'],
                'rating': place['rating'] ?? 4.0,
              });
            }
          }

          places.sort((a, b) => b['rating'].compareTo(a['rating']));
          return places;
        }
      }
    } catch (e) {
      print('Places API 호출 오류: $e');
    }
    return [];
  }

  static void _removeInvalidCharacters(Map<String, dynamic> activity) {
    final title = activity['title']?.toString() ?? '';
    final description = activity['description']?.toString() ?? '';

    String cleanedTitle = title.replaceAll('trải nghiệm', '체험');
    String cleanedDesc = description.replaceAll('trải nghiệm', '체험');

    if (RegExp(r'[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]').hasMatch(cleanedTitle + cleanedDesc)) {
      cleanedTitle = cleanedTitle.replaceAll(RegExp(r'[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]'), '');
      cleanedDesc = cleanedDesc.replaceAll(RegExp(r'[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]'), '');
      print('🔧 외국어 문자 제거: $title');
    }

    activity['title'] = cleanedTitle;
    activity['description'] = cleanedDesc;
  }

  static String _formatTime24(TimeOfDay time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  static Future<List<DayPlan>> _parseTravelPlan(Map<String, dynamic> planData) async {
    final List<DayPlan> plans = [];
    for (var dayData in planData['days']) {
      final activities = <Activity>[];
      for (var activityData in dayData['activities']) {
        LatLng? coordinates;
        if (activityData['coordinates'] != null) {
          try {
            coordinates = LatLng(
              activityData['coordinates']['lat'].toDouble(),
              activityData['coordinates']['lng'].toDouble(),
            );
          } catch (e) {
            print('좌표 파싱 오류: $e');
          }
        }
        activities.add(Activity(
          time: activityData['time']?.toString() ?? '09:00',
          title: activityData['title']?.toString() ?? '활동',
          description: activityData['description']?.toString() ?? '',
          type: _parseActivityType(activityData['type']?.toString() ?? 'sightseeing'),
          location: activityData['location']?.toString() ?? '',
          duration: activityData['duration']?.toString() ?? '1시간',
          coordinates: coordinates,
        ));
      }
      plans.add(DayPlan(
        day: dayData['day'] ?? 1,
        date: DateTime.parse(dayData['date']),
        activities: activities,
      ));
    }
    return plans;
  }

  static ActivityType _parseActivityType(String type) {
    switch (type.toLowerCase()) {
      case 'sightseeing': return ActivityType.sightseeing;
      case 'dining': return ActivityType.dining;
      case 'shopping': return ActivityType.shopping;
      case 'activity': return ActivityType.activity;
      case 'cafe': return ActivityType.cafe;
      default: return ActivityType.sightseeing;
    }
  }

  // Google API 기반 Fallback Plan (한국 제외, 4개 도시만)
  static Future<List<DayPlan>> _generateFallbackPlan(
      String destination,
      DateTime startDate,
      DateTime endDate,
      List<TimeOfDay>? startTimes,
      List<TimeOfDay>? endTimes,
      ) async {
    final days = endDate.difference(startDate).inDays + 1;
    final List<DayPlan> plans = [];

    // 목적지 중심 좌표 가져오기 (한국 제외)
    final centerCoords = _getDestinationCoordinates(destination);

    // Google Places API에서 실제 맛집 가져오기
    final restaurants = await _getRestaurantsFromAPI(centerCoords, days * 3);
    final cafes = await _getCafesFromAPI(centerCoords, days * 2);
    final attractions = await _getAttractionsFromAPI(centerCoords, days * 4);

    for (int i = 0; i < days; i++) {
      final startTime = startTimes?[i] ?? TimeOfDay(hour: 9, minute: 0);
      final endTime = endTimes?[i] ?? TimeOfDay(hour: 19, minute: 0);
      final totalMinutes = ((endTime.hour * 60 + endTime.minute) - (startTime.hour * 60 + startTime.minute)).abs();
      final activityDuration = (totalMinutes / 10).round();
      List<Activity> activities = [];
      int currentMinutes = startTime.hour * 60 + startTime.minute;

      for (int j = 0; j < 10; j++) {
        final hours = (currentMinutes / 60).floor();
        final minutes = currentMinutes % 60;
        final timeString = '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}';

        Activity activity;

        if (j % 3 == 1 && restaurants.isNotEmpty) { // 식사 시간
          final restaurantIndex = (i * 3 + (j ~/ 3)) % restaurants.length;
          final restaurant = restaurants[restaurantIndex];
          activity = Activity(
            time: timeString,
            title: restaurant['name'],
            description: '${restaurant['name']}에서 현지 음식을 즐깁니다',
            type: ActivityType.dining,
            location: restaurant['address'],
            duration: '${(activityDuration / 60).round()}시간',
            coordinates: LatLng(restaurant['lat'], restaurant['lng']),
          );
        } else if (j % 5 == 2 && cafes.isNotEmpty) { // 카페 시간
          final cafeIndex = (i * 2 + (j ~/ 5)) % cafes.length;
          final cafe = cafes[cafeIndex];
          activity = Activity(
            time: timeString,
            title: cafe['name'],
            description: '${cafe['name']}에서 커피와 휴식을 즐깁니다',
            type: ActivityType.cafe,
            location: cafe['address'],
            duration: '${(activityDuration / 60).round()}시간',
            coordinates: LatLng(cafe['lat'], cafe['lng']),
          );
        } else if (attractions.isNotEmpty) { // 관광지
          final attractionIndex = (i * 4 + j) % attractions.length;
          final attraction = attractions[attractionIndex];
          activity = Activity(
            time: timeString,
            title: attraction['name'],
            description: '${attraction['name']} 방문 및 관광',
            type: ActivityType.sightseeing,
            location: attraction['address'],
            duration: '${(activityDuration / 60).round()}시간',
            coordinates: LatLng(attraction['lat'], attraction['lng']),
          );
        } else {
          // API 실패 시 기본 활동
          activity = Activity(
            time: timeString,
            title: '$destination 관광지 ${j + 1}',
            description: '$destination에서의 관광 활동',
            type: ActivityType.sightseeing,
            location: destination,
            duration: '${(activityDuration / 60).round()}시간',
          );
        }

        activities.add(activity);
        currentMinutes += activityDuration;
      }

      plans.add(DayPlan(
        day: i + 1,
        date: startDate.add(Duration(days: i)),
        activities: activities,
      ));
    }
    return plans;
  }

  // Google Places API에서 실제 맛집 가져오기
  static Future<List<Map<String, dynamic>>> _getRestaurantsFromAPI(
      LatLng center, int count) async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/places/nearbysearch?location=${center.latitude},${center.longitude}&radius=5000&type=restaurant&language=ko'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null) {
          List<Map<String, dynamic>> restaurants = [];

          for (var place in data['results'].take(count)) {
            final name = place['name'] ?? '';
            if (!name.toLowerCase().contains('hotel') && place['rating'] != null && place['rating'] >= 4.0) {
              restaurants.add({
                'name': name,
                'address': place['vicinity'] ?? '',
                'lat': place['geometry']['location']['lat'],
                'lng': place['geometry']['location']['lng'],
                'rating': place['rating'],
              });
            }
          }

          restaurants.sort((a, b) => b['rating'].compareTo(a['rating']));
          return restaurants;
        }
      }
    } catch (e) {
      print('맛집 API 호출 오류: $e');
    }
    return [];
  }

  // Google Places API에서 실제 카페 가져오기
  static Future<List<Map<String, dynamic>>> _getCafesFromAPI(
      LatLng center, int count) async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/places/nearbysearch?location=${center.latitude},${center.longitude}&radius=3000&type=cafe&language=ko'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null) {
          List<Map<String, dynamic>> cafes = [];

          for (var place in data['results'].take(count)) {
            final name = place['name'] ?? '';
            if (place['rating'] != null && place['rating'] >= 4.0) {
              cafes.add({
                'name': name,
                'address': place['vicinity'] ?? '',
                'lat': place['geometry']['location']['lat'],
                'lng': place['geometry']['location']['lng'],
                'rating': place['rating'],
              });
            }
          }

          cafes.sort((a, b) => b['rating'].compareTo(a['rating']));
          return cafes;
        }
      }
    } catch (e) {
      print('카페 API 호출 오류: $e');
    }
    return [];
  }

  // Google Places API에서 실제 관광지 가져오기
  static Future<List<Map<String, dynamic>>> _getAttractionsFromAPI(
      LatLng center, int count) async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/places/nearbysearch?location=${center.latitude},${center.longitude}&radius=10000&type=tourist_attraction&language=ko'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null) {
          List<Map<String, dynamic>> attractions = [];

          for (var place in data['results'].take(count)) {
            final name = place['name'] ?? '';
            if (place['rating'] != null && place['rating'] >= 4.0) {
              attractions.add({
                'name': name,
                'address': place['vicinity'] ?? '',
                'lat': place['geometry']['location']['lat'],
                'lng': place['geometry']['location']['lng'],
                'rating': place['rating'],
              });
            }
          }

          attractions.sort((a, b) => b['rating'].compareTo(a['rating']));
          return attractions;
        }
      }
    } catch (e) {
      print('관광지 API 호출 오류: $e');
    }
    return [];
  }

  // 목적지 좌표 (한국 제외, 4개 도시만)
  static LatLng _getDestinationCoordinates(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return LatLng(34.6937, 135.5022);
      case '도쿄':
      case 'tokyo':
        return LatLng(35.682839, 139.759455);
      case '홍콩':
      case 'hong kong':
        return LatLng(22.3, 114.1);
      case '타이페이':
      case 'taipei':
        return LatLng(25.0340, 121.5645);
      default:
        return LatLng(35.682839, 139.759455); // 기본값: 도쿄
    }
  }
}

class TravelTimeResult {
  final String duration;
  final String distance;
  TravelTimeResult({required this.duration, required this.distance});
}
