import 'package:google_maps_flutter/google_maps_flutter.dart';

class DayPlan {
  final int day;
  final DateTime date;
  final List<Activity> activities;

  DayPlan({
    required this.day,
    required this.date,
    required this.activities,
  });
}

class Activity {
  final String time;
  final String title;
  final String description;
  final ActivityType type;
  final String location;
  final String duration;
  final LatLng? coordinates;

  Activity({
    required this.time,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.duration,
    this.coordinates,
  });
}

enum ActivityType {
  sightseeing,
  dining,
  shopping,
  activity,
  transport,
  cafe,
}
