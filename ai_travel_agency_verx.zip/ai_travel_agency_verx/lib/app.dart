// lib/app.dart
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/planner_screen.dart';
import 'screens/map_screen.dart';

class TravelPlannerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Travel Planner',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // home 속성 제거하고 initialRoute만 사용
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/planner': (context) => PlannerScreen(
          travelData: ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?,
        ),
        '/map': (context) => MapScreen(
          travelData: ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?,
        ),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

