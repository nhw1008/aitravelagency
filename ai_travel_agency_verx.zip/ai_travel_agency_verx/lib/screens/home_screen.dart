import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _destinationController = TextEditingController();
  final TextEditingController _budgetController = TextEditingController();
  DateTime? _startDate;
  DateTime? _endDate;

  // 24시간제 드롭다운 선택값 저장 (TextField 완전 제거)
  List<int> _startHours = [];
  List<int> _endHours = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AI Travel Planner'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth > 1024) {
            return _buildDesktopLayout();
          } else if (constraints.maxWidth > 768) {
            return _buildTabletLayout();
          } else {
            return _buildMobileLayout();
          }
        },
      ),
    );
  }

  Widget _buildDesktopLayout() {
    return Row(
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.33,
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            border: Border(right: BorderSide(color: Colors.grey[300]!)),
          ),
          child: _buildPlannerForm(),
        ),
        Expanded(
          child: Container(
            padding: EdgeInsets.all(24),
            child: _buildMainContent(),
          ),
        ),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          _buildPlannerForm(),
          SizedBox(height: 24),
          _buildMainContent(),
        ],
      ),
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCompactPlannerForm(),
          SizedBox(height: 20),
          _buildMainContent(),
        ],
      ),
    );
  }

  Widget _buildPlannerForm() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '여행 계획 만들기',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _destinationController,
              decoration: InputDecoration(
                labelText: '목적지',
                hintText: '예: 오사카, 도쿄, 홍콩',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => _selectStartDate(context),
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today),
                          SizedBox(width: 8),
                          Text(
                            _startDate != null
                                ? '${_startDate!.month}-${_startDate!.day}'
                                : '시작일',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: InkWell(
                    onTap: () => _selectEndDate(context),
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today),
                          SizedBox(width: 8),
                          Text(
                            _endDate != null
                                ? '${_endDate!.month}-${_endDate!.day}'
                                : '종료일',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            TextField(
              controller: _budgetController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: '예산 (원)',
                hintText: '예: 500000',
                prefixIcon: Icon(Icons.attach_money),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 24),
            if (_startDate != null && _endDate != null) ...[
              Text(
                '일차별 가용시간(시작/종료) 설정 (24시간제)',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              SizedBox(height: 8),
              _buildTimeInputList(),
              SizedBox(height: 12),
            ],
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _generateTravelPlan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'AI 여행 계획 생성',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 드롭다운 메뉴로만 시간 입력 (TextField 완전 제거)
  Widget _buildTimeInputList() {
    int days = _endDate!.difference(_startDate!).inDays + 1;

    // 드롭다운 선택값 초기화 (24시간제 기본값)
    if (_startHours.length != days) {
      _startHours = List.generate(days, (_) => 9);  // 기본 9시
      _endHours = List.generate(days, (_) => 19);   // 기본 19시
    }

    return Container(
      height: 200, // 고정 높이로 스크롤 가능
      child: Scrollbar(
        thumbVisibility: true,
        child: ListView.builder(
          itemCount: days,
          itemBuilder: (context, index) {
            final date = _startDate!.add(Duration(days: index));
            return Card(
              margin: EdgeInsets.symmetric(vertical: 4),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Text('${index + 1}일차 (${date.month}-${date.day})'),
                    ),
                    Text('시작:'),
                    SizedBox(width: 8),
                    // 시작시간 드롭다운만 (TextField 제거)
                    DropdownButton<int>(
                      value: _startHours[index],
                      items: List.generate(24, (hour) =>
                          DropdownMenuItem(value: hour, child: Text('${hour}시'))
                      ),
                      onChanged: (hour) {
                        if (hour != null) {
                          setState(() {
                            _startHours[index] = hour;
                          });
                        }
                      },
                    ),
                    SizedBox(width: 12),
                    Text('~'),
                    SizedBox(width: 12),
                    Text('종료:'),
                    SizedBox(width: 8),
                    // 종료시간 드롭다운만 (TextField 제거)
                    DropdownButton<int>(
                      value: _endHours[index],
                      items: List.generate(24, (hour) =>
                          DropdownMenuItem(value: hour, child: Text('${hour}시'))
                      ),
                      onChanged: (hour) {
                        if (hour != null) {
                          setState(() {
                            _endHours[index] = hour;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildCompactPlannerForm() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              '여행 계획 만들기',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _destinationController,
              decoration: InputDecoration(
                labelText: '목적지',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => _selectStartDate(context),
                    child: Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(_startDate != null
                          ? '${_startDate!.month}/${_startDate!.day}'
                          : '시작일'),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: InkWell(
                    onTap: () => _selectEndDate(context),
                    child: Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(_endDate != null
                          ? '${_endDate!.month}/${_endDate!.day}'
                          : '종료일'),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            TextField(
              controller: _budgetController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: '예산',
                prefixIcon: Icon(Icons.attach_money),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
            SizedBox(height: 16),
            if (_startDate != null && _endDate != null) ...[
              Text(
                '일차별 가용시간(시작/종료) 설정 (24시간제)',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              SizedBox(height: 8),
              _buildTimeInputList(),
              SizedBox(height: 12),
            ],
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _generateTravelPlan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                child: Text('계획 생성'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '인기 여행지',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 16),
        Wrap(
          spacing: 16,
          runSpacing: 16,
          children: [
            _buildDestinationCard('오사카', 'assets/images/osaka.jpg'),
            _buildDestinationCard('도쿄', 'assets/images/tokyo.jpg'),
            _buildDestinationCard('홍콩', 'assets/images/hongkong.jpg'),
            _buildDestinationCard('타이페이', 'assets/images/taipei.jpg'),
          ],
        ),
      ],
    );
  }

  Widget _buildDestinationCard(String destination, String imagePath) {
    return Container(
      width: 200,
      height: 150,
      child: Card(
        elevation: 4,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: InkWell(
          onTap: () {
            _destinationController.text = destination;
          },
          child: Stack(
            children: [
              Container(
                color: Colors.blue[100],
                child: Center(
                  child: Icon(
                    Icons.image,
                    size: 50,
                    color: Colors.blue[300],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [Colors.black54, Colors.transparent],
                    ),
                  ),
                  child: Text(
                    destination,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(),
      firstDate: _startDate ?? DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null && picked != _endDate) {
      setState(() {
        _endDate = picked;
      });
    }
  }

  void _generateTravelPlan() {
    if (_destinationController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('목적지를 입력해주세요')),
      );
      return;
    }

    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('여행 날짜를 선택해주세요')),
      );
      return;
    }

    // 드롭다운 선택값을 TimeOfDay로 변환 (24시간제)
    List<TimeOfDay> startTimes = [];
    List<TimeOfDay> endTimes = [];
    int days = _endDate!.difference(_startDate!).inDays + 1;

    for (int i = 0; i < days; i++) {
      int startHour = _startHours.length > i ? _startHours[i] : 9;
      int endHour = _endHours.length > i ? _endHours[i] : 19;

      // 24시간제 범위 검증 (0-23)
      startHour = startHour.clamp(0, 23);
      endHour = endHour.clamp(0, 23);

      startTimes.add(TimeOfDay(hour: startHour, minute: 0));
      endTimes.add(TimeOfDay(hour: endHour, minute: 0));
    }

    Navigator.pushNamed(
      context,
      '/planner',
      arguments: {
        'destination': _destinationController.text,
        'startDate': _startDate,
        'endDate': _endDate,
        'budget': _budgetController.text,
        'startTimes': startTimes, // 24시간제 TimeOfDay 리스트
        'endTimes': endTimes,     // 24시간제 TimeOfDay 리스트
      },
    );
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _budgetController.dispose();
    super.dispose();
  }
}
