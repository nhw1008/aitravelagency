import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart'; // LatLng 임포트 추가
import 'package:ai_travel_agency_verx/screens/map_screen.dart'; // MapScreen 임포트 추가
import '../services/ai_service.dart';
import '../models/travel_plan.dart';

class PlannerScreen extends StatefulWidget {
  final Map? travelData;
  const PlannerScreen({Key? key, this.travelData}) : super(key: key);

  @override
  _PlannerScreenState createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  bool _isLoading = false;
  List<DayPlan> _travelPlan = []; // 타입 명시적으로 지정
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    if (widget.travelData != null) {
      _generateTravelPlan();
    }
  }

  Future<void> _generateTravelPlan() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final travelData = widget.travelData;
      if (travelData == null) {
        throw Exception('여행 데이터가 없습니다.');
      }

      List<TimeOfDay>? startTimes = travelData['startTimes'];
      List<TimeOfDay>? endTimes = travelData['endTimes'];

      final travelPlan = await AIService.generateTravelPlan(
        destination: travelData['destination'] ?? '',
        startDate: travelData['startDate'] as DateTime,
        endDate: travelData['endDate'] as DateTime,
        budget: travelData['budget'] ?? '',
        startTimes: startTimes,
        endTimes: endTimes,
      );

      setState(() {
        _travelPlan = travelPlan;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = '여행 계획 생성 중 오류가 발생했습니다: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('여행 일정'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.map),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MapScreen(
                    travelData: widget.travelData,
                    travelPlan: _travelPlan,
                  ),
                ),
              );
            },
            tooltip: '지도 보기',
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _generateTravelPlan,
            tooltip: '일정 재생성',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('AI가 맞춤 여행 계획을 생성하고 있습니다...'),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, size: 64, color: Colors.red),
            SizedBox(height: 16),
            Text(_errorMessage!),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _generateTravelPlan,
              child: Text('다시 시도'),
            ),
          ],
        ),
      );
    }

    if (_travelPlan.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.schedule, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('여행 계획이 없습니다.'),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('홈으로 돌아가기'),
            ),
          ],
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 1024) {
          return _buildDesktopLayout();
        } else {
          return _buildMobileLayout();
        }
      },
    );
  }

  Widget _buildDesktopLayout() {
    return Row(
      children: [
        Container(
          width: 300,
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            border: Border(right: BorderSide(color: Colors.grey[300]!)),
          ),
          child: _buildTravelInfo(),
        ),
        Expanded(
          child: _buildPlanList(),
        ),
      ],
    );
  }

  Widget _buildMobileLayout() {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(16),
          color: Colors.grey[100],
          child: _buildTravelInfo(),
        ),
        Expanded(child: _buildPlanList()),
      ],
    );
  }

  Widget _buildTravelInfo() {
    final data = widget.travelData;
    if (data == null) return Container();
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '여행 정보',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            _buildInfoRow(Icons.location_on, '목적지', data['destination'] ?? ''),
            _buildInfoRow(Icons.calendar_today, '시작일',
                data['startDate']?.toString().split(' ')[0] ?? ''),
            _buildInfoRow(Icons.calendar_today, '종료일',
                data['endDate']?.toString().split(' ')[0] ?? ''),
            if (data['budget']?.isNotEmpty == true)
              _buildInfoRow(Icons.attach_money, '예산', '${data['budget']}원'),
            SizedBox(height: 16),
            Text(
              '총 ${_travelPlan.length}일 일정',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 8),
            Text(
              '가용시간: 매일 09:00-19:00 (10시간)',
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.grey[600]),
          SizedBox(width: 8),
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.w500)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Widget _buildPlanList() {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: _travelPlan.length,
      itemBuilder: (context, index) {
        return _buildDayCard(_travelPlan[index], index);
      },
    );
  }

  Widget _buildDayCard(DayPlan dayPlan, int dayIndex) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 4,
      child: ExpansionTile(
        title: Text(
          'Day ${dayPlan.day}',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${dayPlan.date.month}/${dayPlan.date.day} (${_getWeekday(dayPlan.date)})',
          style: TextStyle(color: Colors.grey[600]),
        ),
        children: dayPlan.activities
            .map((activity) => _buildActivityTile(activity, dayIndex))
            .toList(),
      ),
    );
  }

  Widget _buildActivityTile(Activity activity, int dayIndex) {
    Color activityColor = _getActivityColor(activity.type);
    return Card(
      margin: EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: activityColor,
          child: Icon(
            _getActivityIcon(activity.type),
            color: Colors.white,
            size: 20,
          ),
        ),
        title: Text(
          activity.title,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(activity.description),
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.access_time, size: 14, color: Colors.grey),
                SizedBox(width: 4),
                Text(
                  '${activity.time} (${activity.duration})',
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
            if (activity.location.isNotEmpty) ...[
              SizedBox(height: 2),
              Row(
                children: [
                  Icon(Icons.location_on, size: 14, color: Colors.grey),
                  SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      activity.location,
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
        trailing: PopupMenuButton(
          itemBuilder: (context) => [
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.map, size: 18),
                  SizedBox(width: 8),
                  Text('지도에서 보기'),
                ],
              ),
              value: 'map',
            ),
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.directions, size: 18),
                  SizedBox(width: 8),
                  Text('길찾기'),
                ],
              ),
              value: 'directions',
            ),
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.edit, size: 18),
                  SizedBox(width: 8),
                  Text('수정'),
                ],
              ),
              value: 'edit',
            ),
          ],
          onSelected: (value) {
            if (value == 'map') {
              // coordinates 또는 기본 좌표 사용 (핵심 수정)
              LatLng? targetCoords;

              if (activity.coordinates != null) {
                targetCoords = activity.coordinates;
                print('✅ 좌표 발견: ${activity.coordinates!.latitude}, ${activity.coordinates!.longitude}');
              } else {
                // coordinates가 없으면 기본 좌표 사용
                targetCoords = LatLng(35.6762, 139.6503);
                print('⚠️ 좌표 정보 없음 - 기본 좌표 사용');
              }

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MapScreen(
                    travelData: widget.travelData,
                    travelPlan: _travelPlan,
                    targetLocation: targetCoords,
                  ),
                ),
              );
            } else if (value == 'directions') {
              _showDirectionsDialog(activity);
            } else if (value == 'edit') {
              _editActivity(activity, dayIndex);
            }
          },
        ),
      ),
    );
  }

  void _showDirectionsDialog(Activity activity) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${activity.title} 길찾기'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.my_location),
              title: Text('현재 위치에서'),
              onTap: () {
                Navigator.pop(context);
                _openExternalMap(activity.coordinates, 'current');
              },
            ),
            ListTile(
              leading: Icon(Icons.map),
              title: Text('지도에서 경로 보기'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MapScreen(
                      travelData: widget.travelData,
                      travelPlan: _travelPlan,
                      targetLocation: activity.coordinates,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _openExternalMap(LatLng? coordinates, String from) async {
    if (coordinates == null) return;
    final url =
        'https://www.google.com/maps/dir/?api=1&destination=${coordinates.latitude},${coordinates.longitude}';
    try {
      // 실제 앱에서는 url_launcher 패키지 사용
      print('지도 URL: $url');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('지도 URL: $url')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('지도 앱을 열 수 없습니다')),
      );
    }
  }

  void _editActivity(Activity activity, int dayIndex) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('활동 수정'),
        content: Text('활동 수정 기능은 곧 추가될 예정입니다.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('확인'),
          ),
        ],
      ),
    );
  }

  Color _getActivityColor(ActivityType type) {
    switch (type) {
      case ActivityType.sightseeing:
        return Colors.blue;
      case ActivityType.dining:
        return Colors.orange;
      case ActivityType.shopping:
        return Colors.purple;
      case ActivityType.activity:
        return Colors.green;
      case ActivityType.transport:
        return Colors.grey;
      case ActivityType.cafe:
        return Colors.brown;
    }
  }

  IconData _getActivityIcon(ActivityType type) {
    switch (type) {
      case ActivityType.sightseeing:
        return Icons.camera_alt;
      case ActivityType.dining:
        return Icons.restaurant;
      case ActivityType.shopping:
        return Icons.shopping_bag;
      case ActivityType.activity:
        return Icons.sports;
      case ActivityType.transport:
        return Icons.directions_car;
      case ActivityType.cafe:
        return Icons.local_cafe;
    }
  }

  String _getWeekday(DateTime date) {
    const weekdays = ['월', '화', '수', '목', '금', '토', '일'];
    return weekdays[date.weekday - 1];
  }
}
