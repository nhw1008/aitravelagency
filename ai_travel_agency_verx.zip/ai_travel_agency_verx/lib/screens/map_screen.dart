// lib/screens/map_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/google_maps_service.dart';
import '../utils/constants.dart';
import '../models/travel_plan.dart';

class MapScreen extends StatefulWidget {
  final Map? travelData;
  final List<DayPlan>? travelPlan; // 실제 여행 계획 데이터
  final LatLng? targetLocation; // 특정 좌표로 이동

  const MapScreen({
    Key? key,
    this.travelData,
    this.travelPlan,
    this.targetLocation,
  }) : super(key: key);

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final Completer<GoogleMapController> _controller = Completer();
  final Map<String, Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  static const LatLng _defaultCenter = LatLng(34.6937, 135.5023);

  String? _selectedMarkerId;
  int _selectedDay = 1;
  String _currentTravelMode = 'WALKING';

  // 일차별 색상 정의
  final List<Color> _dayColors = [
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.cyan,
    Colors.pink,
    Colors.amber,
  ];

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  void _initializeMap() {
    if (widget.travelPlan != null) {
      _createMarkersFromTravelPlan();
    } else if (widget.travelData != null) {
      _createMarkersFromTravelData();
    } else {
      _createDefaultMarkers();
    }

    // 특정 좌표로 이동 (지도에서 보기 기능)
    if (widget.targetLocation != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _moveToLocation(widget.targetLocation!);
      });
    }
  }

  // 실제 여행 계획으로 마커 및 경로 생성 (핵심 개선)
  void _createMarkersFromTravelPlan() {
    if (widget.travelPlan == null) return;

    for (int dayIndex = 0; dayIndex < widget.travelPlan!.length; dayIndex++) {
      final dayPlan = widget.travelPlan![dayIndex];
      final dayColor = _dayColors[dayIndex % _dayColors.length];

      List<LatLng> dayRoutePoints = [];

      for (int activityIndex = 0; activityIndex < dayPlan.activities.length; activityIndex++) {
        final activity = dayPlan.activities[activityIndex];

        if (activity.coordinates != null) {
          final markerId = '${dayPlan.day}_$activityIndex';

          // 마커 생성
          final marker = Marker(
            markerId: MarkerId(markerId),
            position: activity.coordinates!,
            infoWindow: InfoWindow(
              title: activity.title,
              snippet: '${dayPlan.day}일차 ${activity.time} (${activity.duration})',
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(_getHueFromColor(dayColor)),
            onTap: () => _onMarkerTapped(markerId, activity),
          );

          _markers[markerId] = marker;
          dayRoutePoints.add(activity.coordinates!);
        }
      }

      // 실제 도로를 따라가는 경로 생성 (핵심 개선)
      if (dayRoutePoints.length > 1) {
        _createRealRoute(dayRoutePoints, dayPlan.day, dayColor);
      }
    }

    setState(() {});
  }

  // 실제 도로 경로 생성 함수 (새로 추가)
  Future<void> _createRealRoute(List<LatLng> waypoints, int day, Color color) async {
    try {
      List<LatLng> routePoints = [];

      if (waypoints.length == 2) {
        // 2개 지점: 직접 경로
        routePoints = await GoogleMapsService.getDirections(
          origin: waypoints.first,
          destination: waypoints.last,
          travelMode: _currentTravelMode,
        );
      } else if (waypoints.length > 2) {
        // 3개 이상 지점: 경유지 포함 경로
        routePoints = await GoogleMapsService.getMultiStopRoute(
          origin: waypoints.first,
          destination: waypoints.last,
          waypoints: waypoints.sublist(1, waypoints.length - 1),
          travelMode: _currentTravelMode,
        );
      }

      if (routePoints.isNotEmpty) {
        final polyline = Polyline(
          polylineId: PolylineId('day_${day}_route'),
          points: routePoints,
          color: color,
          width: 4,
          patterns: [PatternItem.dash(20), PatternItem.gap(10)],
        );

        setState(() {
          // 기존 해당 일차 경로 제거
          _polylines.removeWhere((p) => p.polylineId.value == 'day_${day}_route');
          _polylines.add(polyline);
        });

        print('✅ Day $day 실제 경로 생성 완료 (${routePoints.length}개 지점)');
      }
    } catch (e) {
      print('실제 경로 생성 오류: $e');
      // 실패 시 직선 경로로 fallback
      final polyline = Polyline(
        polylineId: PolylineId('day_${day}_route_fallback'),
        points: waypoints,
        color: color.withOpacity(0.6),
        width: 3,
        patterns: [PatternItem.dash(15), PatternItem.gap(15)],
      );

      setState(() {
        _polylines.add(polyline);
      });
    }
  }

  // 색상을 Google Maps Hue로 변환
  double _getHueFromColor(Color color) {
    if (color == Colors.red) return BitmapDescriptor.hueRed;
    if (color == Colors.blue) return BitmapDescriptor.hueBlue;
    if (color == Colors.green) return BitmapDescriptor.hueGreen;
    if (color == Colors.orange) return BitmapDescriptor.hueOrange;
    if (color == Colors.purple) return BitmapDescriptor.hueViolet;
    if (color == Colors.cyan) return BitmapDescriptor.hueCyan;
    if (color == Colors.pink) return BitmapDescriptor.hueRose;
    if (color == Colors.amber) return BitmapDescriptor.hueYellow;
    return BitmapDescriptor.hueRed;
  }

  // 특정 좌표로 카메라 이동 (지도에서 보기 기능)
  Future<void> _moveToLocation(LatLng location) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: location, zoom: 16.0),
      ),
    );
  }

  void _createMarkersFromTravelData() {
    final destination = widget.travelData?['destination'] ?? '';
    LatLng destinationCoords = _getDestinationCoordinates(destination);

    final mainMarker = Marker(
      markerId: MarkerId('main_destination'),
      position: destinationCoords,
      infoWindow: InfoWindow(
        title: destination,
        snippet: '메인 목적지',
      ),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
    );

    setState(() {
      _markers['main_destination'] = mainMarker;
    });

    _addAIGeneratedPlaces();
  }

  Future<void> _addAIGeneratedPlaces() async {
    final destination = widget.travelData?['destination'] ?? '';
    final destinationCoords = _getDestinationCoordinates(destination);
    _searchAndAddNearbyPlaces(destinationCoords);
  }

  Future<void> _searchAndAddNearbyPlaces(LatLng center) async {
    try {
      final touristAttractions = await GoogleMapsService.searchNearbyPlaces(
        location: center,
        type: 'tourist_attraction',
        radius: 10000,
      );

      final restaurants = await GoogleMapsService.searchNearbyPlaces(
        location: center,
        type: 'restaurant',
        radius: 5000,
      );

      final cafes = await GoogleMapsService.searchNearbyPlaces(
        location: center,
        type: 'cafe',
        radius: 3000,
      );

      for (var place in touristAttractions.take(5)) {
        _addPlaceMarker(place, 'tourist_attraction');
      }

      for (var place in restaurants.take(3)) {
        _addPlaceMarker(place, 'restaurant');
      }

      for (var place in cafes.take(3)) {
        _addPlaceMarker(place, 'cafe');
      }

      _createRoute();
      setState(() {});
    } catch (e) {
      print('장소 검색 오류: $e');
    }
  }

  void _addPlaceMarker(PlaceInfo place, String type) {
    final marker = Marker(
      markerId: MarkerId(place.placeId),
      position: place.location,
      infoWindow: InfoWindow(
        title: place.name,
        snippet: '${place.address} ⭐ ${place.rating}',
      ),
      icon: _getMarkerIconByType(type),
      onTap: () => _onPlaceMarkerTapped(place.placeId),
    );
    _markers[place.placeId] = marker;
  }

  BitmapDescriptor _getMarkerIconByType(String type) {
    switch (type) {
      case 'tourist_attraction':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue);
      case 'restaurant':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange);
      case 'cafe':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow);
      default:
        return BitmapDescriptor.defaultMarker;
    }
  }

  void _createDefaultMarkers() {
    final defaultPlaces = [
      {'name': '도톤보리', 'lat': 34.6694, 'lng': 135.5054, 'type': '관광지'},
      {'name': '유니버설 스튜디오 재팬', 'lat': 34.6665, 'lng': 135.4806, 'type': '액티비티'},
      {'name': '시부야 스크램블', 'lat': 35.6585, 'lng': 139.7015, 'type': '관광지'},
      {'name': '도쿄 타워', 'lat': 35.6586, 'lng': 139.7455, 'type': '랜드마크'},
      {'name': '빅토리아 피크', 'lat': 22.2753, 'lng': 114.1470, 'type': '전망대'},
      {'name': '티엔탄 부처', 'lat': 22.2538, 'lng': 113.9049, 'type': '문화유산'},
      {'name': '타이페이 101', 'lat': 25.0340, 'lng': 121.5645, 'type': '랜드마크'},
      {'name': '스린 야시장', 'lat': 25.0880, 'lng': 121.5240, 'type': '음식'},
    ];

    for (var place in defaultPlaces) {
      final marker = Marker(
        markerId: MarkerId(place['name'] as String),
        position: LatLng(place['lat'] as double, place['lng'] as double),
        infoWindow: InfoWindow(
          title: place['name'] as String,
          snippet: place['type'] as String,
        ),
        icon: _getMarkerIcon(place['type'] as String),
        onTap: () => _onPlaceMarkerTapped(place['name'] as String),
      );
      _markers[place['name'] as String] = marker;
    }

    setState(() {});
  }

  void _createRoute() {
    List<LatLng> routePoints = _markers.values.map((marker) => marker.position).toList();
    if (routePoints.length > 1) {
      final polyline = Polyline(
        polylineId: PolylineId('travel_route'),
        points: routePoints,
        color: Colors.blue,
        width: 3,
        patterns: [PatternItem.dash(20), PatternItem.gap(10)],
      );
      _polylines.add(polyline);
    }
  }

  BitmapDescriptor _getMarkerIcon(String type) {
    switch (type) {
      case '맛집':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange);
      case '카페':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow);
      case '숙소':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
      case '관광지':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue);
      case '쇼핑':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueMagenta);
      case '엔터테인먼트':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet);
      default:
        return BitmapDescriptor.defaultMarker;
    }
  }

  LatLng _getDestinationCoordinates(String destination) {
    switch (destination.toLowerCase()) {
      case '오사카':
      case 'osaka':
        return LatLng(34.6937, 135.5022);
      case '도쿄':
      case 'tokyo':
        return LatLng(35.682839, 139.759455);
      case '홍콩':
      case 'hong kong':
        return LatLng(22.3, 114.1);
      case '타이페이':
      case 'taipei':
        return LatLng(25.0340, 121.5645);
      default:
        return _defaultCenter;
    }
  }

  // 여행 계획 마커 탭 이벤트 (개선됨)
  void _onMarkerTapped(String markerId, Activity activity) {
    setState(() {
      _selectedMarkerId = markerId;
    });
    _showActivityInfo(activity);
  }

  // 일반 장소 마커 탭 이벤트
  void _onPlaceMarkerTapped(String markerId) {
    setState(() {
      _selectedMarkerId = markerId;
    });
    _showMarkerInfo(markerId);
  }

  // 활동 정보 표시 (개선됨)
  void _showActivityInfo(Activity activity) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(16),
        height: 250,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              activity.title,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              activity.description,
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.access_time, size: 16),
                SizedBox(width: 4),
                Text('${activity.time} (${activity.duration})'),
              ],
            ),
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.location_on, size: 16),
                SizedBox(width: 4),
                Expanded(child: Text(activity.location)),
              ],
            ),
            SizedBox(height: 16),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    if (activity.coordinates != null) {
                      _moveToLocation(activity.coordinates!);
                    }
                    Navigator.pop(context);
                  },
                  icon: Icon(Icons.location_on),
                  label: Text('위치로 이동'),
                ),
                SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    if (activity.coordinates != null) {
                      _getDirections(activity.coordinates!);
                    }
                  },
                  icon: Icon(Icons.directions),
                  label: Text('길찾기'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMarkerInfo(String markerId) {
    final marker = _markers[markerId];
    if (marker != null) {
      showModalBottomSheet(
        context: context,
        builder: (context) => Container(
          padding: EdgeInsets.all(16),
          height: 200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                marker.infoWindow.title ?? '',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                marker.infoWindow.snippet ?? '',
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  ElevatedButton.icon(
                    onPressed: () => _moveToMarker(marker.position),
                    icon: Icon(Icons.location_on),
                    label: Text('위치로 이동'),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton.icon(
                    onPressed: () => _getDirections(marker.position),
                    icon: Icon(Icons.directions),
                    label: Text('길찾기'),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
  }

  Future<void> _moveToMarker(LatLng position) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: position, zoom: 15.0),
      ),
    );
    Navigator.pop(context);
  }

  Future<void> _getDirections(LatLng destination) async {
    if (_markers.isEmpty) return;

    LatLng origin = _markers.values.first.position;
    try {
      final polylinePoints = await GoogleMapsService.getDirections(
        origin: origin,
        destination: destination,
        travelMode: _currentTravelMode,
      );

      setState(() {
        _polylines.removeWhere((p) => p.polylineId.value == 'direction_route');
        _polylines.add(
          Polyline(
            polylineId: PolylineId('direction_route'),
            points: polylinePoints,
            color: Colors.green,
            width: 5,
          ),
        );
      });

      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('경로가 지도에 표시되었습니다')),
      );
    } catch (e) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('길찾기 실패: $e')),
      );
    }
  }

  Future<void> _fitMarkersInView() async {
    if (_markers.isEmpty) return;

    final GoogleMapController controller = await _controller.future;
    double minLat = _markers.values.first.position.latitude;
    double maxLat = _markers.values.first.position.latitude;
    double minLng = _markers.values.first.position.longitude;
    double maxLng = _markers.values.first.position.longitude;

    for (var marker in _markers.values) {
      minLat = minLat < marker.position.latitude ? minLat : marker.position.latitude;
      maxLat = maxLat > marker.position.latitude ? maxLat : marker.position.latitude;
      minLng = minLng < marker.position.longitude ? minLng : marker.position.longitude;
      maxLng = maxLng > marker.position.longitude ? maxLng : marker.position.longitude;
    }

    controller.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLng),
          northeast: LatLng(maxLat, maxLng),
        ),
        100.0,
      ),
    );
  }

  // 교통수단 선택 기능 추가
  void _showTravelModeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('교통수단 선택'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.directions_walk),
              title: Text('도보'),
              onTap: () => _changeTravelMode('WALKING'),
            ),
            ListTile(
              leading: Icon(Icons.directions_car),
              title: Text('자동차'),
              onTap: () => _changeTravelMode('DRIVING'),
            ),
            ListTile(
              leading: Icon(Icons.directions_transit),
              title: Text('대중교통'),
              onTap: () => _changeTravelMode('TRANSIT'),
            ),
            ListTile(
              leading: Icon(Icons.directions_bike),
              title: Text('자전거'),
              onTap: () => _changeTravelMode('BICYCLING'),
            ),
          ],
        ),
      ),
    );
  }

  void _changeTravelMode(String mode) {
    Navigator.pop(context);
    setState(() {
      _currentTravelMode = mode;
    });

    // 선택된 교통수단으로 경로 재생성
    _polylines.clear();
    if (widget.travelPlan != null) {
      _createMarkersFromTravelPlan();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('교통수단이 ${_getTravelModeText(mode)}로 변경되었습니다')),
    );
  }

  String _getTravelModeText(String mode) {
    switch (mode) {
      case 'WALKING': return '도보';
      case 'DRIVING': return '자동차';
      case 'TRANSIT': return '대중교통';
      case 'BICYCLING': return '자전거';
      default: return '도보';
    }
  }

  // 일차별 필터링 (추가 기능)
  void _filterByDay(int day) {
    setState(() {
      _selectedDay = day;
      // 선택된 일차의 마커만 표시하는 로직 추가 가능
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('여행 지도'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.directions),
            onPressed: _showTravelModeDialog,
            tooltip: '교통수단 선택',
          ),
          IconButton(
            icon: Icon(Icons.fit_screen),
            onPressed: _fitMarkersInView,
            tooltip: '전체 보기',
          ),
          IconButton(
            icon: Icon(Icons.layers),
            onPressed: _showMapTypeDialog,
            tooltip: '지도 타입',
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
            },
            initialCameraPosition: CameraPosition(
              target: widget.targetLocation ??
                  (widget.travelData != null
                      ? _getDestinationCoordinates(widget.travelData!['destination'] ?? '')
                      : _defaultCenter),
              zoom: 11.0,
            ),
            markers: _markers.values.toSet(),
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
          ),

          // 일차별 필터 버튼 (추가)
          if (widget.travelPlan != null)
            Positioned(
              top: 16,
              left: 16,
              child: Container(
                height: 50,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: widget.travelPlan!.length,
                  itemBuilder: (context, index) {
                    final day = index + 1;
                    final color = _dayColors[index % _dayColors.length];
                    return Padding(
                      padding: EdgeInsets.only(right: 8),
                      child: FilterChip(
                        label: Text('$day일차'),
                        selected: _selectedDay == day,
                        selectedColor: color.withOpacity(0.3),
                        onSelected: (selected) => _filterByDay(day),
                      ),
                    );
                  },
                ),
              ),
            ),

          // 교통수단 표시
          Positioned(
            top: 80,
            left: 16,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(_getTravelModeIcon(_currentTravelMode), size: 16),
                  SizedBox(width: 4),
                  Text(_getTravelModeText(_currentTravelMode)),
                ],
              ),
            ),
          ),

          // 지도 컨트롤 패널
          Positioned(
            top: 16,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: "zoom_in",
                  mini: true,
                  onPressed: _zoomIn,
                  child: Icon(Icons.add),
                ),
                SizedBox(height: 8),
                FloatingActionButton(
                  heroTag: "zoom_out",
                  mini: true,
                  onPressed: _zoomOut,
                  child: Icon(Icons.remove),
                ),
              ],
            ),
          ),

          // 여행 정보 카드
          if (widget.travelData != null)
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Card(
                elevation: 8,
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${widget.travelData!['destination']} 여행',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '${widget.travelData!['startDate']?.toString().split(' ')[0]} ~ ${widget.travelData!['endDate']?.toString().split(' ')[0]}',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      if (widget.travelData!['budget']?.isNotEmpty == true)
                        Text(
                          '예산: ${widget.travelData!['budget']}원',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushNamed(context, '/planner', arguments: widget.travelData);
        },
        label: Text('일정 보기'),
        icon: Icon(Icons.schedule),
      ),
    );
  }

  IconData _getTravelModeIcon(String mode) {
    switch (mode) {
      case 'WALKING': return Icons.directions_walk;
      case 'DRIVING': return Icons.directions_car;
      case 'TRANSIT': return Icons.directions_transit;
      case 'BICYCLING': return Icons.directions_bike;
      default: return Icons.directions_walk;
    }
  }

  Future<void> _zoomIn() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.zoomIn());
  }

  Future<void> _zoomOut() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.zoomOut());
  }

  void _showMapTypeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('지도 타입 선택'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text('일반'),
              onTap: () => _changeMapType(MapType.normal),
            ),
            ListTile(
              title: Text('위성'),
              onTap: () => _changeMapType(MapType.satellite),
            ),
            ListTile(
              title: Text('지형'),
              onTap: () => _changeMapType(MapType.terrain),
            ),
            ListTile(
              title: Text('하이브리드'),
              onTap: () => _changeMapType(MapType.hybrid),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _changeMapType(MapType mapType) async {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('지도 타입이 변경되었습니다')),
    );
  }
}
