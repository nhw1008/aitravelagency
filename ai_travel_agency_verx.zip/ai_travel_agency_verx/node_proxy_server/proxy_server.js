const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Perplexity AI 프록시
app.post('/api/ai', async (req, res) => {
  try {
    const response = await axios.post(
      'https://api.perplexity.ai/chat/completions',
      req.body,
      {
        headers: {
          'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    res.json(response.data);
  } catch (error) {
    res.status(error.response?.status || 500).json({
      error: error.message,
      detail: error.response?.data
    });
  }
});

// Places API 프록시
app.get('/api/places/nearbysearch', async (req, res) => {
  try {
    const { location, radius, type } = req.query;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'GOOGLE_MAPS_API_KEY is missing in .env' });
    }
    const response = await axios.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', {
      params: {
        location: location,
        radius: radius,
        type: type,
        key: apiKey
      }
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Routes API 프록시 (Directions API 사용, .env 기반 보안)
app.post('/api/routes', async (req, res) => {
  try {
    const { waypoints, mode = 'WALKING' } = req.body;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'GOOGLE_MAPS_API_KEY is missing in .env' });
    }
    if (!waypoints || waypoints.length < 2) {
      return res.status(400).json({ error: 'At least two waypoints are required.' });
    }
    // Directions API (일반적으로 무료 쿼터 넉넉)
    const origin = `${waypoints[0].lat},${waypoints[0].lng}`;
    const destination = `${waypoints[waypoints.length - 1].lat},${waypoints[waypoints.length - 1].lng}`;
    const response = await axios.get('https://maps.googleapis.com/maps/api/directions/json', {
      params: {
        origin: origin,
        destination: destination,
        mode: mode.toLowerCase(),
        key: apiKey
      }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Routes API Error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => console.log('Proxy server running on port 3000'));
