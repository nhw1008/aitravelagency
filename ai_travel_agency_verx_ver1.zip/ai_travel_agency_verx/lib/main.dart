import 'package:flutter/material.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'app.dart';

void main() {
  // 웹 환경에서 URL 전략 설정 (# 제거)
  setUrlStrategy(PathUrlStrategy());
  runApp(TravelPlannerApp());
}


