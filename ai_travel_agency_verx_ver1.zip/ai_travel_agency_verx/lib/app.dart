// lib/app.dart
import 'package:flutter/material.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'screens/home_screen.dart';
import 'screens/planner_screen.dart';
import 'screens/map_screen.dart';

class TravelPlannerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Travel Planner',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        // 웹에 적합한 반응형 테마 설정
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // 반응형 홈 화면 설정
      home: ResponsiveWrapper.builder(
        ScreenTypeLayout.builder(
          breakpoints: ScreenBreakpoints(
              desktop: 1024,
              tablet: 768,
              mobile: 600
          ),
          mobile: (_) => HomeScreen(),
          tablet: (_) => HomeScreen(),
          desktop: (_) => HomeScreen(),
        ),
        maxWidth: 1200,
        minWidth: 450,
        defaultScale: true,
        breakpoints: [
          ResponsiveBreakpoint.resize(450, name: MOBILE),
          ResponsiveBreakpoint.autoScale(800, name: TABLET),
          ResponsiveBreakpoint.resize(1000, name: DESKTOP),
        ],
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/planner': (context) => PlannerScreen(),
        '/map': (context) => MapScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
