// lib/services/ai_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/constants.dart';
import '../models/travel_plan.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class AIService {
  static Future<List<DayPlan>> generateTravelPlan({
    required String destination,
    required DateTime startDate,
    required DateTime endDate,
    required String budget,
  }) async {
    try {
      final days = endDate.difference(startDate).inDays + 1;

      final prompt = '''
여행 계획을 JSON 형식으로 생성해주세요.
목적지: $destination
시작일: ${startDate.toString().split(' ')[0]}
종료일: ${endDate.toString().split(' ')[0]}
일수: $days일
예산: $budget원

다음 JSON 형식으로 응답해주세요:
{
  "days": [
    {
      "day": 1,
      "date": "2025-05-26",
      "activities": [
        {
          "time": "09:00",
          "title": "활동 제목",
          "description": "활동 설명",
          "type": "sightseeing",
          "location": "구체적인 위치",
          "duration": "2시간",
          "coordinates": {
            "lat": 37.5665,
            "lng": 126.9780
          }
        }
      ]
    }
  ]
}

type은 다음 중 하나여야 합니다: sightseeing, dining, shopping, activity, transport, cafe
실제 존재하는 장소와 정확한 좌표를 포함해주세요.
JSON만 응답하고 다른 텍스트는 포함하지 마세요.
''';

      final response = await http.post(
        Uri.parse(AppConstants.aiApiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppConstants.aiApiKey}',
        },
        body: jsonEncode({
          'model': 'llama-3.1-sonar-small-128k-online',
          'messages': [
            {
              'role': 'system',
              'content': '당신은 전문 여행 플래너입니다. 실제 존재하는 장소와 정확한 정보만 제공하고, 요청된 JSON 형식으로만 응답하세요.'
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'max_tokens': 2000,
          'temperature': 0.7,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final aiResponse = data['choices'][0]['message']['content'];

        // JSON 파싱 시도
        try {
          final planData = jsonDecode(aiResponse);
          return _parseTravelPlan(planData);
        } catch (e) {
          print('JSON 파싱 오류: $e');
          print('AI 응답: $aiResponse');
          return _generateFallbackPlan(destination, startDate, endDate);
        }
      } else {
        print('API 응답 오류: ${response.statusCode}');
        print('응답 내용: ${response.body}');
        throw Exception('Perplexity AI API 호출 실패: ${response.statusCode}');
      }
    } catch (e) {
      print('AI Service Error: $e');
      // 실패 시 기본 계획 반환
      return _generateFallbackPlan(destination, startDate, endDate);
    }
  }

  static List<DayPlan> _parseTravelPlan(Map<String, dynamic> planData) {
    final List<DayPlan> plans = [];

    for (var dayData in planData['days']) {
      final activities = <Activity>[];

      for (var activityData in dayData['activities']) {
        LatLng? coordinates;
        if (activityData['coordinates'] != null) {
          try {
            coordinates = LatLng(
              activityData['coordinates']['lat'].toDouble(),
              activityData['coordinates']['lng'].toDouble(),
            );
          } catch (e) {
            print('좌표 파싱 오류: $e');
          }
        }

        activities.add(Activity(
          time: activityData['time'] ?? '09:00',
          title: activityData['title'] ?? '활동',
          description: activityData['description'] ?? '',
          type: _parseActivityType(activityData['type'] ?? 'sightseeing'),
          location: activityData['location'] ?? '',
          duration: activityData['duration'] ?? '1시간',
          coordinates: coordinates,
        ));
      }

      plans.add(DayPlan(
        day: dayData['day'] ?? 1,
        date: DateTime.parse(dayData['date']),
        activities: activities,
      ));
    }

    return plans;
  }

  static ActivityType _parseActivityType(String type) {
    switch (type.toLowerCase()) {
      case 'sightseeing':
        return ActivityType.sightseeing;
      case 'dining':
        return ActivityType.dining;
      case 'shopping':
        return ActivityType.shopping;
      case 'activity':
        return ActivityType.activity;
      case 'transport':
        return ActivityType.transport;
      case 'cafe':
        return ActivityType.cafe;
      default:
        return ActivityType.sightseeing;
    }
  }

  static List<DayPlan> _generateFallbackPlan(String destination, DateTime startDate, DateTime endDate) {
    final days = endDate.difference(startDate).inDays + 1;
    final List<DayPlan> plans = [];

    for (int i = 0; i < days; i++) {
      plans.add(DayPlan(
        day: i + 1,
        date: startDate.add(Duration(days: i)),
        activities: [
          Activity(
            time: '09:00',
            title: '$destination 관광',
            description: '주요 관광지 방문',
            type: ActivityType.sightseeing,
            location: destination,
            duration: '3시간',
          ),
          Activity(
            time: '12:00',
            title: '현지 맛집',
            description: '지역 특색 음식 체험',
            type: ActivityType.dining,
            location: destination,
            duration: '1시간',
          ),
          Activity(
            time: '15:00',
            title: '쇼핑 및 휴식',
            description: '기념품 구매 및 카페 휴식',
            type: ActivityType.shopping,
            location: destination,
            duration: '2시간',
          ),
        ],
      ));
    }

    return plans;
  }
}
