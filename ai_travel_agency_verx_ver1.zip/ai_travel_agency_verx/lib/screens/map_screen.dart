// lib/screens/map_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  final Map<String, dynamic>? travelData;

  const MapScreen({Key? key, this.travelData}) : super(key: key);

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final Completer<GoogleMapController> _controller = Completer();
  final Map<String, Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  // 기본 위치 (서울)
  static const LatLng _defaultCenter = LatLng(37.5665, 126.9780);

  // 현재 선택된 마커 정보
  String? _selectedMarkerId;

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  void _initializeMap() {
    // 여행 데이터가 있으면 마커 생성
    if (widget.travelData != null) {
      _createMarkersFromTravelData();
    } else {
      _createDefaultMarkers();
    }
  }

  void _createMarkersFromTravelData() {
    final destination = widget.travelData?['destination'] ?? '';

    // 목적지별 기본 좌표 설정 (실제로는 Geocoding API 사용)
    LatLng destinationCoords = _getDestinationCoordinates(destination);

    // 메인 목적지 마커
    final mainMarker = Marker(
      markerId: MarkerId('main_destination'),
      position: destinationCoords,
      infoWindow: InfoWindow(
        title: destination,
        snippet: '메인 목적지',
      ),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
    );

    setState(() {
      _markers['main_destination'] = mainMarker;
    });

    // 추천 장소들 추가 (AI가 생성한 데이터 기반)
    _addRecommendedPlaces(destinationCoords);
  }

  void _createDefaultMarkers() {
    // 기본 인기 장소들
    final defaultPlaces = [
      {'name': '경복궁', 'lat': 37.5796, 'lng': 126.9770, 'type': '관광지'},
      {'name': '명동', 'lat': 37.5636, 'lng': 126.9834, 'type': '쇼핑'},
      {'name': '홍대', 'lat': 37.5563, 'lng': 126.9236, 'type': '엔터테인먼트'},
      {'name': '강남역', 'lat': 37.4979, 'lng': 127.0276, 'type': '비즈니스'},
    ];

    for (var place in defaultPlaces) {
      final marker = Marker(
        markerId: MarkerId(place['name'] as String),
        position: LatLng(place['lat'] as double, place['lng'] as double),
        infoWindow: InfoWindow(
          title: place['name'] as String,
          snippet: place['type'] as String,
        ),
        icon: _getMarkerIcon(place['type'] as String),
        onTap: () => _onMarkerTapped(place['name'] as String),
      );

      _markers[place['name'] as String] = marker;
    }

    setState(() {});
  }

  void _addRecommendedPlaces(LatLng center) {
    // AI 추천 장소들 (실제로는 AI API에서 받아온 데이터)
    final recommendedPlaces = [
      {'name': '추천 맛집 1', 'offset': [0.01, 0.01], 'type': '맛집'},
      {'name': '추천 카페', 'offset': [-0.01, 0.01], 'type': '카페'},
      {'name': '추천 숙소', 'offset': [0.01, -0.01], 'type': '숙소'},
      {'name': '추천 관광지', 'offset': [-0.01, -0.01], 'type': '관광지'},
    ];

    for (var place in recommendedPlaces) {
      final offset = place['offset'] as List<double>;
      final marker = Marker(
        markerId: MarkerId(place['name'] as String),
        position: LatLng(
          center.latitude + offset[0],
          center.longitude + offset[1],
        ),
        infoWindow: InfoWindow(
          title: place['name'] as String,
          snippet: place['type'] as String,
        ),
        icon: _getMarkerIcon(place['type'] as String),
        onTap: () => _onMarkerTapped(place['name'] as String),
      );

      _markers[place['name'] as String] = marker;
    }

    // 경로 생성
    _createRoute();
    setState(() {});
  }

  void _createRoute() {
    // 마커들을 연결하는 경로 생성
    List<LatLng> routePoints = _markers.values.map((marker) => marker.position).toList();

    if (routePoints.length > 1) {
      final polyline = Polyline(
        polylineId: PolylineId('travel_route'),
        points: routePoints,
        color: Colors.blue,
        width: 3,
        patterns: [PatternItem.dash(20), PatternItem.gap(10)],
      );

      _polylines.add(polyline);
    }
  }

  BitmapDescriptor _getMarkerIcon(String type) {
    switch (type) {
      case '맛집':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange);
      case '카페':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow);
      case '숙소':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
      case '관광지':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue);
      case '쇼핑':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueMagenta);
      case '엔터테인먼트':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet);
      default:
        return BitmapDescriptor.defaultMarker;
    }
  }

  LatLng _getDestinationCoordinates(String destination) {
    // 실제로는 Geocoding API 사용
    switch (destination.toLowerCase()) {
      case '제주도':
      case '제주':
        return LatLng(33.4996, 126.5312);
      case '부산':
        return LatLng(35.1796, 129.0756);
      case '서울':
        return LatLng(37.5665, 126.9780);
      case '경주':
        return LatLng(35.8562, 129.2247);
      default:
        return _defaultCenter;
    }
  }

  void _onMarkerTapped(String markerId) {
    setState(() {
      _selectedMarkerId = markerId;
    });

    // 마커 정보 표시
    _showMarkerInfo(markerId);
  }

  void _showMarkerInfo(String markerId) {
    final marker = _markers[markerId];
    if (marker != null) {
      showModalBottomSheet(
        context: context,
        builder: (context) => Container(
          padding: EdgeInsets.all(16),
          height: 200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                marker.infoWindow.title ?? '',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                marker.infoWindow.snippet ?? '',
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  ElevatedButton.icon(
                    onPressed: () => _moveToMarker(marker.position),
                    icon: Icon(Icons.location_on),
                    label: Text('위치로 이동'),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton.icon(
                    onPressed: () => _getDirections(marker.position),
                    icon: Icon(Icons.directions),
                    label: Text('길찾기'),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
  }

  Future<void> _moveToMarker(LatLng position) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: position, zoom: 15.0),
      ),
    );
    Navigator.pop(context);
  }

  void _getDirections(LatLng destination) {
    // 실제로는 Directions API 호출
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('길찾기 기능은 추후 구현 예정입니다')),
    );
    Navigator.pop(context);
  }

  Future<void> _fitMarkersInView() async {
    if (_markers.isEmpty) return;

    final GoogleMapController controller = await _controller.future;

    double minLat = _markers.values.first.position.latitude;
    double maxLat = _markers.values.first.position.latitude;
    double minLng = _markers.values.first.position.longitude;
    double maxLng = _markers.values.first.position.longitude;

    for (var marker in _markers.values) {
      minLat = minLat < marker.position.latitude ? minLat : marker.position.latitude;
      maxLat = maxLat > marker.position.latitude ? maxLat : marker.position.latitude;
      minLng = minLng < marker.position.longitude ? minLng : marker.position.longitude;
      maxLng = maxLng > marker.position.longitude ? maxLng : marker.position.longitude;
    }

    controller.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLng),
          northeast: LatLng(maxLat, maxLng),
        ),
        100.0, // padding
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('여행 지도'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.fit_screen),
            onPressed: _fitMarkersInView,
            tooltip: '전체 보기',
          ),
          IconButton(
            icon: Icon(Icons.layers),
            onPressed: _showMapTypeDialog,
            tooltip: '지도 타입',
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
            },
            initialCameraPosition: CameraPosition(
              target: widget.travelData != null
                  ? _getDestinationCoordinates(widget.travelData!['destination'] ?? '')
                  : _defaultCenter,
              zoom: 11.0,
            ),
            markers: _markers.values.toSet(),
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
          ),

          // 지도 컨트롤 패널
          Positioned(
            top: 16,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: "zoom_in",
                  mini: true,
                  onPressed: _zoomIn,
                  child: Icon(Icons.add),
                ),
                SizedBox(height: 8),
                FloatingActionButton(
                  heroTag: "zoom_out",
                  mini: true,
                  onPressed: _zoomOut,
                  child: Icon(Icons.remove),
                ),
              ],
            ),
          ),

          // 여행 정보 카드
          if (widget.travelData != null)
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Card(
                elevation: 8,
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${widget.travelData!['destination']} 여행',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '${widget.travelData!['startDate']?.toString().split(' ')[0]} ~ ${widget.travelData!['endDate']?.toString().split(' ')[0]}',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      if (widget.travelData!['budget']?.isNotEmpty == true)
                        Text(
                          '예산: ${widget.travelData!['budget']}원',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushNamed(context, '/planner', arguments: widget.travelData);
        },
        label: Text('일정 보기'),
        icon: Icon(Icons.schedule),
      ),
    );
  }

  Future<void> _zoomIn() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.zoomIn());
  }

  Future<void> _zoomOut() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.zoomOut());
  }

  void _showMapTypeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('지도 타입 선택'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text('일반'),
              onTap: () => _changeMapType(MapType.normal),
            ),
            ListTile(
              title: Text('위성'),
              onTap: () => _changeMapType(MapType.satellite),
            ),
            ListTile(
              title: Text('지형'),
              onTap: () => _changeMapType(MapType.terrain),
            ),
            ListTile(
              title: Text('하이브리드'),
              onTap: () => _changeMapType(MapType.hybrid),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _changeMapType(MapType mapType) async {
    // 실제로는 GoogleMap 위젯의 mapType 속성을 동적으로 변경해야 함
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('지도 타입이 변경되었습니다')),
    );
  }
}
