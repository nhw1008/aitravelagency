// lib/screens/planner_screen.dart
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class PlannerScreen extends StatefulWidget {
  final Map<String, dynamic>? travelData;

  const PlannerScreen({Key? key, this.travelData}) : super(key: key);

  @override
  _PlannerScreenState createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  bool _isLoading = false;
  List<DayPlan> _travelPlan = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    if (widget.travelData != null) {
      _generateTravelPlan();
    }
  }

  Future<void> _generateTravelPlan() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // AI API 호출 시뮬레이션 (실제로는 AI API 사용)
      await Future.delayed(Duration(seconds: 2));

      final mockPlan = _generateMockPlan();

      setState(() {
        _travelPlan = mockPlan;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = '여행 계획 생성 중 오류가 발생했습니다: $e';
        _isLoading = false;
      });
    }
  }

  List<DayPlan> _generateMockPlan() {
    final destination = widget.travelData?['destination'] ?? '서울';
    final startDate = widget.travelData?['startDate'] as DateTime?;
    final endDate = widget.travelData?['endDate'] as DateTime?;

    if (startDate == null || endDate == null) {
      return [];
    }

    final days = endDate.difference(startDate).inDays + 1;
    List<DayPlan> plans = [];

    for (int i = 0; i < days; i++) {
      final currentDate = startDate.add(Duration(days: i));
      plans.add(_createDayPlan(i + 1, currentDate, destination));
    }

    return plans;
  }

  DayPlan _createDayPlan(int day, DateTime date, String destination) {
    // 목적지별 맞춤 계획 생성
    List<Activity> activities = [];

    switch (destination.toLowerCase()) {
      case '제주도':
      case '제주':
        activities = _createJejuActivities(day);
        break;
      case '부산':
        activities = _createBusanActivities(day);
        break;
      case '서울':
        activities = _createSeoulActivities(day);
        break;
      default:
        activities = _createDefaultActivities(day);
    }

    return DayPlan(
      day: day,
      date: date,
      activities: activities,
    );
  }

  List<Activity> _createJejuActivities(int day) {
    if (day == 1) {
      return [
        Activity(
          time: '09:00',
          title: '제주공항 도착',
          description: '렌터카 픽업 및 숙소 체크인',
          type: ActivityType.transport,
          location: '제주국제공항',
          duration: '1시간',
        ),
        Activity(
          time: '11:00',
          title: '성산일출봉',
          description: '유네스코 세계자연유산, 제주의 대표 관광지',
          type: ActivityType.sightseeing,
          location: '서귀포시 성산읍',
          duration: '2시간',
        ),
        Activity(
          time: '14:00',
          title: '해녀의 집',
          description: '신선한 해산물 점심식사',
          type: ActivityType.dining,
          location: '성산읍 해녀의집',
          duration: '1시간',
        ),
        Activity(
          time: '16:00',
          title: '섭지코지',
          description: '아름다운 해안절벽과 유채꽃밭',
          type: ActivityType.sightseeing,
          location: '서귀포시 성산읍',
          duration: '1.5시간',
        ),
        Activity(
          time: '19:00',
          title: '제주 흑돼지 맛집',
          description: '제주 특산품 흑돼지 저녁식사',
          type: ActivityType.dining,
          location: '제주시 연동',
          duration: '1.5시간',
        ),
      ];
    } else {
      return [
        Activity(
          time: '09:00',
          title: '한라산 국립공원',
          description: '한라산 등반 또는 둘레길 트레킹',
          type: ActivityType.activity,
          location: '제주시 해안동',
          duration: '4시간',
        ),
        Activity(
          time: '14:00',
          title: '제주 전통시장',
          description: '동문시장에서 점심 및 쇼핑',
          type: ActivityType.shopping,
          location: '제주시 일도이동',
          duration: '2시간',
        ),
        Activity(
          time: '17:00',
          title: '제주 카페거리',
          description: '애월 카페거리에서 커피타임',
          type: ActivityType.cafe,
          location: '제주시 애월읍',
          duration: '1시간',
        ),
      ];
    }
  }

  List<Activity> _createBusanActivities(int day) {
    return [
      Activity(
        time: '09:00',
        title: '해운대 해수욕장',
        description: '부산의 대표 해변에서 산책',
        type: ActivityType.sightseeing,
        location: '해운대구',
        duration: '2시간',
      ),
      Activity(
        time: '12:00',
        title: '부산 돼지국밥',
        description: '부산 대표 음식 돼지국밥 점심',
        type: ActivityType.dining,
        location: '서면',
        duration: '1시간',
      ),
      Activity(
        time: '15:00',
        title: '감천문화마을',
        description: '알록달록한 벽화마을 탐방',
        type: ActivityType.sightseeing,
        location: '사하구 감천동',
        duration: '2시간',
      ),
      Activity(
        time: '18:00',
        title: '자갈치시장',
        description: '신선한 해산물 저녁식사',
        type: ActivityType.dining,
        location: '중구 자갈치로',
        duration: '1.5시간',
      ),
    ];
  }

  List<Activity> _createSeoulActivities(int day) {
    return [
      Activity(
        time: '09:00',
        title: '경복궁',
        description: '조선왕조의 대표 궁궐 관람',
        type: ActivityType.sightseeing,
        location: '종로구 사직로',
        duration: '2시간',
      ),
      Activity(
        time: '12:00',
        title: '북촌한옥마을',
        description: '전통 한옥마을에서 점심',
        type: ActivityType.dining,
        location: '종로구 계동',
        duration: '1.5시간',
      ),
      Activity(
        time: '15:00',
        title: '명동 쇼핑',
        description: '명동에서 쇼핑 및 간식',
        type: ActivityType.shopping,
        location: '중구 명동',
        duration: '2시간',
      ),
      Activity(
        time: '18:00',
        title: '한강공원',
        description: '한강에서 치킨과 맥주',
        type: ActivityType.activity,
        location: '여의도한강공원',
        duration: '2시간',
      ),
    ];
  }

  List<Activity> _createDefaultActivities(int day) {
    return [
      Activity(
        time: '09:00',
        title: '관광지 방문',
        description: '지역 대표 관광지 탐방',
        type: ActivityType.sightseeing,
        location: '시내',
        duration: '2시간',
      ),
      Activity(
        time: '12:00',
        title: '현지 맛집',
        description: '지역 특색 음식 점심',
        type: ActivityType.dining,
        location: '시내',
        duration: '1시간',
      ),
      Activity(
        time: '15:00',
        title: '문화체험',
        description: '지역 문화 체험 활동',
        type: ActivityType.activity,
        location: '시내',
        duration: '2시간',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('여행 일정'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.map),
            onPressed: () {
              Navigator.pushNamed(context, '/map', arguments: widget.travelData);
            },
            tooltip: '지도 보기',
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _generateTravelPlan,
            tooltip: '일정 재생성',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('AI가 맞춤 여행 계획을 생성하고 있습니다...'),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, size: 64, color: Colors.red),
            SizedBox(height: 16),
            Text(_errorMessage!),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _generateTravelPlan,
              child: Text('다시 시도'),
            ),
          ],
        ),
      );
    }

    if (_travelPlan.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.schedule, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('여행 계획이 없습니다.'),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('홈으로 돌아가기'),
            ),
          ],
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 1024) {
          return _buildDesktopLayout();
        } else {
          return _buildMobileLayout();
        }
      },
    );
  }

  Widget _buildDesktopLayout() {
    return Row(
      children: [
        // 왼쪽 사이드바 - 여행 정보
        Container(
          width: 300,
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            border: Border(right: BorderSide(color: Colors.grey[300]!)),
          ),
          child: _buildTravelInfo(),
        ),
        // 오른쪽 메인 - 일정 리스트
        Expanded(
          child: _buildPlanList(),
        ),
      ],
    );
  }

  Widget _buildMobileLayout() {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(16),
          color: Colors.grey[100],
          child: _buildTravelInfo(),
        ),
        Expanded(child: _buildPlanList()),
      ],
    );
  }

  Widget _buildTravelInfo() {
    final data = widget.travelData;
    if (data == null) return Container();

    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '여행 정보',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            _buildInfoRow(Icons.location_on, '목적지', data['destination'] ?? ''),
            _buildInfoRow(Icons.calendar_today, '시작일',
                data['startDate']?.toString().split(' ')[0] ?? ''),
            _buildInfoRow(Icons.calendar_today, '종료일',
                data['endDate']?.toString().split(' ')[0] ?? ''),
            if (data['budget']?.isNotEmpty == true)
              _buildInfoRow(Icons.attach_money, '예산', '${data['budget']}원'),
            SizedBox(height: 16),
            Text(
              '총 ${_travelPlan.length}일 일정',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.grey[600]),
          SizedBox(width: 8),
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.w500)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Widget _buildPlanList() {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: _travelPlan.length,
      itemBuilder: (context, index) {
        return _buildDayCard(_travelPlan[index]);
      },
    );
  }

  Widget _buildDayCard(DayPlan dayPlan) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 4,
      child: ExpansionTile(
        title: Text(
          'Day ${dayPlan.day}',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${dayPlan.date.month}/${dayPlan.date.day} (${_getWeekday(dayPlan.date)})',
          style: TextStyle(color: Colors.grey[600]),
        ),
        children: dayPlan.activities.map((activity) => _buildActivityTile(activity)).toList(),
      ),
    );
  }

  Widget _buildActivityTile(Activity activity) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: _getActivityColor(activity.type),
        child: Icon(
          _getActivityIcon(activity.type),
          color: Colors.white,
          size: 20,
        ),
      ),
      title: Text(activity.title),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(activity.description),
          SizedBox(height: 4),
          Row(
            children: [
              Icon(Icons.access_time, size: 14, color: Colors.grey),
              SizedBox(width: 4),
              Text('${activity.time} (${activity.duration})',
                  style: TextStyle(fontSize: 12, color: Colors.grey)),
              SizedBox(width: 12),
              Icon(Icons.location_on, size: 14, color: Colors.grey),
              SizedBox(width: 4),
              Expanded(
                child: Text(activity.location,
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
              ),
            ],
          ),
        ],
      ),
      trailing: PopupMenuButton(
        itemBuilder: (context) => [
          PopupMenuItem(
            child: Text('지도에서 보기'),
            value: 'map',
          ),
          PopupMenuItem(
            child: Text('메모 추가'),
            value: 'memo',
          ),
        ],
        onSelected: (value) {
          if (value == 'map') {
            Navigator.pushNamed(context, '/map', arguments: widget.travelData);
          }
        },
      ),
    );
  }

  Color _getActivityColor(ActivityType type) {
    switch (type) {
      case ActivityType.sightseeing:
        return Colors.blue;
      case ActivityType.dining:
        return Colors.orange;
      case ActivityType.shopping:
        return Colors.purple;
      case ActivityType.activity:
        return Colors.green;
      case ActivityType.transport:
        return Colors.grey;
      case ActivityType.cafe:
        return Colors.brown;
    }
  }

  IconData _getActivityIcon(ActivityType type) {
    switch (type) {
      case ActivityType.sightseeing:
        return Icons.camera_alt;
      case ActivityType.dining:
        return Icons.restaurant;
      case ActivityType.shopping:
        return Icons.shopping_bag;
      case ActivityType.activity:
        return Icons.sports;
      case ActivityType.transport:
        return Icons.directions_car;
      case ActivityType.cafe:
        return Icons.local_cafe;
    }
  }

  String _getWeekday(DateTime date) {
    const weekdays = ['월', '화', '수', '목', '금', '토', '일'];
    return weekdays[date.weekday - 1];
  }
}

// 데이터 모델들
class DayPlan {
  final int day;
  final DateTime date;
  final List<Activity> activities;

  DayPlan({
    required this.day,
    required this.date,
    required this.activities,
  });
}

class Activity {
  final String time;
  final String title;
  final String description;
  final ActivityType type;
  final String location;
  final String duration;

  Activity({
    required this.time,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.duration,
  });
}

enum ActivityType {
  sightseeing,
  dining,
  shopping,
  activity,
  transport,
  cafe,
}
