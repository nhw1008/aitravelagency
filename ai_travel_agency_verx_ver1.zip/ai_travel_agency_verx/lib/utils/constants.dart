class AppConstants {
  static const String googleMapsApiKey = String.fromEnvironment('GOOGLE_MAPS_API_KEY');
  static const String aiApiKey = String.fromEnvironment('AI_API_KEY');
  static const String aiApiUrl = 'https://api.perplexity.ai/chat/completions';
}
